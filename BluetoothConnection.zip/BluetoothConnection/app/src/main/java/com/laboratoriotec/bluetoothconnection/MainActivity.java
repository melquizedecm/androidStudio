package com.laboratoriotec.bluetoothconnection;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
/*
1 boton activar
1 boton desactivar
1 boton listar dispositivos
1 Visible al telefono
1 ListView
 */

    Button btnActivar,btnDesactivar, btnVisible, btnListarDispositivos;
    ListView lista;
    private Set<BluetoothDevice> vinculados;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice bluetoothDevice;
    private BluetoothSocket bluetoothSocket;
    private ArrayAdapter adapter;
    String address="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnActivar=(Button) findViewById(R.id.buttonActivar);
        btnDesactivar=(Button) findViewById(R.id.buttonDesactivar);
        btnVisible=(Button) findViewById(R.id.buttonVisualizar);
        btnListarDispositivos=(Button) findViewById(R.id.buttonVerDispositivos);
        lista = (ListView) findViewById(R.id.listView);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Tu dispositivo no soporta bluetooth",Toast.LENGTH_LONG).show();
        }
    }

    public void activarBluetooth(View view) {
        if (!bluetoothAdapter.isEnabled()){
            Intent encender = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE); //preparar solicitud para encender
            startActivityForResult(encender,0);
            Toast.makeText(this,"Bluetooth ya está Activado",Toast.LENGTH_LONG).show();
        }
    }

    public void desactivarBluetooth(View view) {
        bluetoothAdapter.disable();
        Toast.makeText(this,"Bluetooth Apagado",Toast.LENGTH_LONG).show();
    }

    public void visualizarBluetooth(View view) {
        Intent visible= new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        visible.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,30);
        startActivity(visible);
    }

    public void listarDispositivosBluetooth(View view) {
        vinculados = bluetoothAdapter.getBondedDevices();
        ArrayList listaDispositivos= new ArrayList();
        for (BluetoothDevice bt : vinculados) listaDispositivos.add(bt.getName()+ "\n" + bt.getAddress());
        adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,listaDispositivos);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(onItemClickListener);
    }

    private  AdapterView.OnItemClickListener onItemClickListener=new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String fila=((TextView) view).getText().toString();
            address = fila.substring(fila.length()-17);    //obtiene la dirección
            Toast.makeText(getApplicationContext(),address,Toast.LENGTH_LONG).show();
            bluetoothDevice= bluetoothAdapter.getRemoteDevice(address);  // realiza la conexion a la dirección indicada
            

        }
    };


}
